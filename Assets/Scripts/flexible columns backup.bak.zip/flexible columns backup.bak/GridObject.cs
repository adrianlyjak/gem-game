﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class GridObject : MonoBehaviour
{

	public Grid grid;
	public Color color;
	public bool selected = false;
	private bool isMoving = false;
	public bool isFalling = false;
	private Vector3 startPosition;
	private Vector3 endPosition;
	private float startTime;
	private float speed;
	private float journeyLength;
	public float timePerUnit = 0.005f;
	private bool checkedGravity = false;
	private bool isGlowing = false;
	private Color glowColor;
	private float glowStartTime;
	private float glowInterval = 1.0f;
	public int column;

	public void SetColor ()
	{
		color = grid.controller.RandomColor ();
		gameObject.renderer.material.color = color;
	}

	void Update ()
	{
		if (isMoving) {
			Move ();
		}
		if (isGlowing) {
			GlowPulse ();
		}
	}

	void Move ()
	{
		float distCovered = (Time.time - startTime) * speed;
		float fracJourney = distCovered / journeyLength;
		Vector3 newPosition = Vector3.Lerp (startPosition, endPosition, fracJourney); 
		if (fracJourney < 1.0f) {
			gameObject.transform.position = newPosition;
			if (isFalling && fracJourney > 0.5f) {
				GravityCheck ();
			}
		} else {

			gameObject.transform.position = endPosition;
			if (isFalling && !grid.IsObjectAt (grid.NextGridLocation (this))) {
				checkedGravity = false;
				GravityCheck ();
				ContinueFalling ();
			} else {
				isMoving = false;
				if (isFalling) {
					isFalling = false;
					checkedGravity = false;
					GravityCheck ();
					checkedGravity = false;
					grid.RemoveFalling (this);
				}
			}
		}
				
	}

	void GlowPulse ()
	{
		float timeLocation = (Time.time - glowStartTime) % (glowInterval * 2.0f);
		float percentProgess = (timeLocation % glowInterval) / glowInterval;
		if (timeLocation > (glowInterval)) {
			// increase glow
			percentProgess = 1.0f - percentProgess;
		}
		float rOffset = 1f - color.r;
		float gOffset = 1f - color.g;
		float bOffset = 1f - color.b;
		float rMin = Mathf.Min (rOffset, 0.2f);
		float gMin = Mathf.Min (gOffset, 0.2f);
		float bMin = Mathf.Min (bOffset, 0.2f);
		gameObject.renderer.material.color = new Color (color.r + (rMin * percentProgess), color.g + (gMin * percentProgess), color.b + (bMin * percentProgess), gameObject.renderer.material.color.a);
	}

	public void StartFalling ()
	{
		if ((!grid.IsObjectAt (grid.NextGridLocation (this)))) {
			grid.AddFalling (this);
			isFalling = true;
			ContinueFalling ();
		}
	}

	private void ContinueFalling ()
	{

		MoveTo (grid.NextGridLocation (this));
				
	}

	void GravityCheck ()
	{
		if (!checkedGravity) {
			GridObject prevObject = grid.PreviousGridObject (this);
			if (prevObject != null) {
				if (!prevObject.isFalling) {
					prevObject.StartFalling ();
					checkedGravity = true;

				}
			} else if (!(IsAtTop ())) {
				grid.SpawnObjectAtCol (Position ().x);
			}
		}
	}
	
	public void MoveTo (Vector3 pos)
	{
		isMoving = true;
		startPosition = gameObject.transform.position;
		endPosition = pos;
		startTime = Time.time;
		journeyLength = Vector3.Distance (startPosition, endPosition);
		speed = journeyLength / timePerUnit;
	}
	
	public Vector3 Position ()
	{
		if (isMoving) {
			return endPosition;
		} else {
			return gameObject.transform.position;
		}
	}

	void OnMouseOver ()
	{
		if (Input.GetMouseButtonDown (0) && !grid.IsRegenerating ()) {
			ToggleSelected ();
			bool fm = false;
			int matchingRows = 0;
			foreach (List<Vector3> row in grid.Successions()) {
				if (row.Contains (Position ())) {
					matchingRows = matchingRows + 1;
				}
			}
			foreach (KeyValuePair<KeyValuePair<GridObject,GridObject>, List<GridObject>> matchObj in grid.controller.PossibleMatches()) {
				if (matchObj.Key.Key == this) {
					fm = true;
					Debug.Log ("me at:" + Position () + " matches: " + matchObj.Key.Value.Position () + " for match sequence of size: " + matchObj.Value.Count () + " starting at:" + matchObj.Value.First ().Position () + " ending:" + matchObj.Value.Last ().Position () + " rows containing my position: " + matchingRows);

				}

			}
			if (!fm) {
				Debug.Log ("me at:" + Position () + " rows containing my position: " + matchingRows);
			}
			Debug.Log ("minY:" + grid.MinY(Position().x) + "maxY:" + grid.MaxY (Position().x) + " min+" + grid.min + "max+" + grid.max);
		}
		if (isGlowing && Input.GetMouseButtonDown (1)) {
			grid.controller.ShowMatches (this);
		}

	}

	void ToggleSelected ()
	{ 
		selected = !selected;
		if (selected) {
			gameObject.renderer.material.color = new Color (color.r, color.g, color.b, 0.5f);
			grid.controller.AddSelected (this);
		} else {
			grid.audio.PlayOneShot (grid.controller.deselectSound);
			grid.controller.RemoveSelected (this);
			BeNotSelected ();
		}
	}

	public void  Glow ()
	{
		isGlowing = true;
		glowColor = new Color (Mathf.Min (color.r * 1.2f, 1), Mathf.Min (color.g * 1.2f, 1), Mathf.Min (color.b * 1.2f, 1));
		glowStartTime = Time.time;


	}

	public void StopGlow ()
	{
		isGlowing = false;
		gameObject.renderer.material.color = color;
	}

	public void BeNotSelected ()
	{
		selected = false;
		gameObject.renderer.material.color = color;
	}
		
	public bool IsFloating ()
	{
		return !grid.IsObjectAt (grid.NextGridLocation (this));
				
	}
		
	public bool IsAtTop ()
	{
		return grid.TopCellAt (Position ().x) == gameObject.transform.position;
	}

	public bool Matches (GridObject other)
	{
		return other.color == color;
	}

	public bool IsFalling ()
	{
		return isFalling;
	}
}	