﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class GridController : MonoBehaviour
{

	public int numColors = 4;
	public Color[] colors;
	private GridObject selectedGridObject;
	public Grid grid;
	public int sequenceSize = 3;
	public Score score;
	public bool isHex = false;
	private bool isGlowing = false;
	public List<List<GridObject>> cachedMatches = null;
	private Dictionary<KeyValuePair<GridObject,GridObject>,List<GridObject>> cachedPossibleMatches = null;
	private List<GridObject> switchingObjects = new List<GridObject> ();
	public AudioClip selectSound;
	public AudioClip rejectSound;
	public AudioClip matchSound;
	public AudioClip noMovesSound;
	public AudioClip deselectSound;

	void InitGrid ()
	{
		
		if (isHex) {
			grid = gameObject.GetComponent<HexGrid> ();
		} else {
			grid = gameObject.GetComponent<SquareGrid> ();
		}
		grid.controller = this;
		grid.Initialize ();
	}
	
	void InitScore ()
	{
		score = gameObject.GetComponent<Score> ();
		score.controller = this;
	}

	void InitColors ()
	{
		colors = new Color [15];
				
		/*	for (float i = 0; i < numColors; i++) {
						float start = 1.0f - (i / (numColors - 1.0f));
						float middle = ((((float)numColors - 1) / 2.0f) - Mathf.Abs (i - (((float)numColors - 1) / 2.0f))) / (((float)numColors - 1) / 2.0f);
						float end = (i / (numColors - 1.0f));
						colors [(int)i] = new Color (end, middle, start);
				} */		

		colors [0] = (new Color (0.282f, 0.784f, 0.086f, 1));
		colors [1] = (new Color (0.878f, 0.349f, 0.616f, 1));
		colors [2] = (new Color (0.2f, 0.498f, 0.627f, 1));
		colors [3] = (new Color (0.898f, 0.561f, 0.176f, 1));
		colors [4] = (new Color (0.639f, 0.62f, 0.6f, 1));
		colors [5] = (new Color (0.686f, 1f, 0.141f, 1));
		colors [6] = (new Color (0.286f, 0.788f, 0.788f, 1));
		colors [7] = (new Color (0.286f, 0.788f, 0.788f, 1));
		colors [8] = (new Color (0.059f, 0.533f, 0.384f, 1));
		colors [9] = (new Color (0.58f, 0.18f, 0.439f, 1));
		colors [10] = (new Color (0.247f, 0.227f, 0.588f, 1));
		colors [11] = (new Color (0.675f, 0.247f, 0.173f, 1));
		colors [12] = (new Color (0.949f, 0.933f, 0.914f, 1));
		colors [13] = (new Color (0.216f, 0.216f, 0.216f, 1));
		colors [14] = (new Color (1f, 0.792f, 0.722f, 1));


	}

	void Start ()
	{
		InitColors ();
		InitScore ();
		InitGrid ();
	}

	public Color RandomColor ()
	{
		return colors [Random.Range (0, numColors)];
	}
	

	// manage selected grid objects
	public void AddSelected (GridObject newlySelected)
	{
		if (selectedGridObject == null) {
			audio.PlayOneShot (selectSound);
			selectedGridObject = newlySelected;
		} else {
			if ((grid.AdjacentGridObjects (newlySelected).Contains (selectedGridObject))) {
				grid.Switch (selectedGridObject, newlySelected);
				switchingObjects.Add (selectedGridObject);
				switchingObjects.Add (newlySelected);
				newlySelected.BeNotSelected ();
				selectedGridObject.BeNotSelected ();
				selectedGridObject = null;
			} else {
				audio.PlayOneShot (selectSound);
				selectedGridObject.BeNotSelected ();
				selectedGridObject = newlySelected;
			}
		}
	}
	
	public void RemoveSelected (GridObject newlySelected)
	{
		selectedGridObject = null;
	}
		
	public void CheckMatches ()
	{		
		List<List<GridObject>> matches = Matches ();
		if (matches.Count () > 0) {
			audio.PlayOneShot (matchSound);
			Debug.Log ("checking matches");
			// Add the scores
			foreach (List<GridObject> matchSequence in matches) {
				score.AddForMatch (matchSequence);
			}
			// Then destroy the objects
			foreach (List<GridObject> matchSequence in matches) {
		
				foreach (GridObject gridObject in matchSequence) {
					grid.RemoveObject (gridObject);
				}
			}
			grid.OnGridObjectsDestroyed (); 
		} else if (PossibleMatches ().Count () == 0) {
			Debug.Log ("no matches");
			audio.PlayOneShot (noMovesSound);
			grid.ResetBoard ();
		}
		cachedMatches = null;
		cachedPossibleMatches = null;

		//PossibleMatches ();
	}
		
	public Dictionary<KeyValuePair<GridObject,GridObject>,List<GridObject>> PossibleMatches ()
	{

		if (cachedPossibleMatches == null) {
			cachedPossibleMatches = new Dictionary<KeyValuePair<GridObject,GridObject>,List<GridObject>> ();
			foreach (List<Vector3> row in grid.Successions ()) {
				GridObject lastObject = null;
				bool isAtEndOfMatch = false;
				List<GridObject> currentMatch = new List<GridObject> ();
				foreach (Vector3 point in row) {
					GridObject currentObject = grid.ObjectAt (point);
					if (lastObject == null || currentObject.Matches (lastObject)) {
						currentMatch.Add (currentObject);
					} else {
						isAtEndOfMatch = true;
					}

					int trailingIndex = row.IndexOf (point);
					if (row.Count () == trailingIndex) {
						isAtEndOfMatch = true;
					}
					// split
					

					if (isAtEndOfMatch && (trailingIndex + 1 < row.Count ())) {
						GridObject nextNextObj = grid.ObjectAt (row.ElementAt (trailingIndex + 1));
						List<GridObject> perpMatches = new List<GridObject> ();
						if (nextNextObj.Matches (lastObject)) {
							foreach (GridObject matchObj in grid.AdjacentGridObjects (currentObject)) {
								if (matchObj != lastObject && matchObj != nextNextObj && lastObject.Matches (matchObj)) {
									perpMatches.Add (matchObj);
								}
							}
							// if we have a perpendicular match, see if there's enough for a split
							if (perpMatches.Count () > 0) {
								int sequenceIndex = trailingIndex;
								List<GridObject> splitMatch = new List<GridObject> (currentMatch);
								bool isAtEnd = false;
								while (!isAtEnd) {
									sequenceIndex = sequenceIndex + 1;	
									if (sequenceIndex < row.Count ()) {
										nextNextObj = grid.ObjectAt (row.ElementAt (sequenceIndex));
										if (nextNextObj.Matches (lastObject)) {
											splitMatch.Add (nextNextObj);
										} else {
											isAtEnd = true;
										}
									} else {
										isAtEnd = true;
									}
								}
								if (splitMatch.Count () >= sequenceSize - 1) {
									foreach (GridObject matchObj in perpMatches) {
										KeyValuePair<GridObject,GridObject> matchToValue = new KeyValuePair<GridObject,GridObject> (matchObj, currentObject);
										if (!(cachedPossibleMatches.ContainsKey (matchToValue))) {								
											cachedPossibleMatches.Add (matchToValue, splitMatch);
										}
									}
								}
							}
						}
					}

				 
					if ((currentMatch.Count () >= sequenceSize - 1) && isAtEndOfMatch) {
						// leading


						int leadingIndex = row.FindIndex (pt => pt == currentMatch.First ().Position ()) - 1;
						if (leadingIndex >= 0) {
							GridObject leadingObj = grid.ObjectAt (row.ElementAt (leadingIndex));
														
							foreach (GridObject matchObj in grid.AdjacentGridObjects (leadingObj)) {
								if (matchObj != currentMatch.First () && lastObject.Matches (matchObj)) {
									KeyValuePair<GridObject,GridObject> matchToValue = new KeyValuePair<GridObject,GridObject> (matchObj, leadingObj);
									if (!(cachedPossibleMatches.ContainsKey (matchToValue))) {								
										cachedPossibleMatches.Add (matchToValue, currentMatch);
									}
								}
							}
						}

						// trailing

					//	Debug.Log ("looking for obj at index: " + trailingIndex + " row count: " + row.Count () + " row start,end: " + row.First () + ", " + row.Last ());
						foreach (GridObject matchObj in grid.AdjacentGridObjects(currentObject)) {
							if (matchObj != lastObject && lastObject.Matches (matchObj)) {
								KeyValuePair<GridObject,GridObject> matchToValue = new KeyValuePair<GridObject, GridObject> (matchObj, currentObject);
								if (!(cachedPossibleMatches.ContainsKey (matchToValue))) {

									cachedPossibleMatches.Add (matchToValue, currentMatch);
								}
							}
						}

					} 

					if (isAtEndOfMatch) {
						isAtEndOfMatch = false;
						currentMatch = new List<GridObject> ();
						currentMatch.Add (currentObject);
					}
					
					lastObject = currentObject;
				}
				// have to check if the final match is big enough 
			}
		}
		return cachedPossibleMatches;
	}

	public List<List<GridObject>> Matches ()
	{
		
		//	if (cachedMatches == null) {
		cachedMatches = new List<List<GridObject>> ();
		foreach (List<Vector3> row in grid.Successions ()) {
			GridObject lastObject = null;
			List<GridObject> currentMatch = new List<GridObject> ();
			foreach (Vector3 point in row) {
				GridObject currentObject = grid.ObjectAt (point);
				if (lastObject == null || currentObject.Matches (lastObject)) {
					currentMatch.Add (currentObject);
				} else {
					// add the finished match if its big enough before we start a new one
					if (currentMatch.Count >= sequenceSize) {
						cachedMatches.Add (currentMatch);
					}
					currentMatch = new List<GridObject> ();
					currentMatch.Add (currentObject);
				}
				
				lastObject = currentObject;
			}
			// have to check if the final match is big enough 
			if (currentMatch.Count >= sequenceSize) {
				cachedMatches.Add (currentMatch);
			}
		}
		//	}
		return cachedMatches;
	}

	void Update ()
	{
		if (switchingObjects.Count () == 2) {
			GridObject first = switchingObjects.First ();
			if (first.Position () == first.gameObject.transform.position) {
				if (Matches ().Count > 0) {
					score.AddMove ();

					CheckMatches ();
				} else {
					Debug.Log ("cant move there");
					audio.PlayOneShot (rejectSound);
					grid.Switch (first, switchingObjects [1]);
				}
				switchingObjects = new List<GridObject> ();
			}
		}
		if (Input.GetMouseButtonDown (1)) {
			grid.ResetBoard ();
		}
	}

	public void ShowMatches (GridObject obj)
	{

		KeyValuePair<GridObject,GridObject> theKey = new KeyValuePair<GridObject,GridObject > ();
		foreach (KeyValuePair<GridObject,GridObject> key in PossibleMatches().Keys) {
			if (key.Key == obj) {
				theKey = key;
			}
		}
		theKey.Value.Glow ();
		foreach (GridObject seqMatch in PossibleMatches()[theKey]) {
			seqMatch.Glow ();
		}
	}

	public void ShowHint ()
	{
/*		
		foreach (KeyValuePair<GridObject,GridObject> key in PossibleMatches().Keys) {
			key.Key.Glow ();
		}
*/		

		PossibleMatches ().ElementAt(Random.Range (0, PossibleMatches().Count ())).Key.Key.Glow ();

}

	public void HideHints ()
	{
		foreach (GridObject obj in grid.AllGridObjects()) {
			obj.StopGlow ();
		}
	}
}
